package com.devglan.service.impl;

import com.devglan.dao.ImageRepository;
import com.devglan.dao.UserDao;
import com.devglan.model.ImageModel;
import com.devglan.model.User;
import com.devglan.model.UserDto;
import com.devglan.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

@Transactional
@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {
	
	
    @Autowired
	ImageRepository imageRepository;
    
	@Autowired
	private UserDao userDao;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	
	
	public List<User> findAll() {
		List<User> list = new ArrayList<>();
		List<User> userList = (List<User>) userDao.findAll();
		for(User user: userList) {
			if(user.getIdImage()!=null) {
				ImageModel img = new ImageModel(user.getIdImage().getId(),user.getIdImage().getName(), user.getIdImage().getType(),
						decompressBytes(user.getIdImage().getPicByte()));
				user.setIdImage(img);
			}
			
			 list.add(user);
			
		}
		//userDao.findAll().iterator().forEachRemaining(list::add);
		return list;
	}
	
	public static byte[] compressBytes(byte[] data) {
		Deflater deflater = new Deflater();
		deflater.setInput(data);
		deflater.finish();
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		while (!deflater.finished()) {
			int count = deflater.deflate(buffer);
			outputStream.write(buffer, 0, count);
		}
		try {
			outputStream.close();
		} catch (IOException e) {
		}
		System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);
		return outputStream.toByteArray();
	}

	@Override
	public void delete(int id) {
		Optional<User> user= userDao.findById(id);
		if(user.isPresent()) {
			User userObj = user.get();
			if(userObj.getIdImage()!=null) {
				Long idImage= userObj.getIdImage().getId();
				imageRepository.deleteById(idImage);
			}
			userDao.deleteById(id);		
			
		}
		
		
	}

	@Override
	public User findOne(String username) {
		return userDao.findByUsername(username);
	}
	
	
	public static byte[] decompressBytes(byte[] data) {
		Inflater inflater = new Inflater();
		inflater.setInput(data);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		try {
			while (!inflater.finished()) {
				int count = inflater.inflate(buffer);
				outputStream.write(buffer, 0, count);
			}
			outputStream.close();
		} catch (IOException ioe) {
		} catch (DataFormatException e) {
		}
		return outputStream.toByteArray();
	} 
	
	@Override
	public User findById(int id) {
		Optional<User> optionalUser = userDao.findById(id);
		if(optionalUser.isPresent()) {
			String imageName= optionalUser.get().getIdImage().getName();
			ImageModel img = new ImageModel(optionalUser.get().getIdImage().getId(),optionalUser.get().getIdImage().getName(),optionalUser.get().getIdImage().getType(),decompressBytes(optionalUser.get().getIdImage().getPicByte()));
			User test =  new User();
			test =optionalUser.get();
			test.setIdImage(img);
			return test;
			
		}else {
			 return null;	
		}
		  
		
	}

    @Override
    public UserDto update(UserDto userDto) {
        User user = findById(userDto.getId());
        if(user != null) {
            BeanUtils.copyProperties(userDto, user, "password", "username");
            userDao.save(user);
        }
        return userDto;
    }

    @Override
    public User save(UserDto user) {
	    User newUser = new User();
	    newUser.setUsername(user.getUsername());
	    newUser.setFirstName(user.getFirstName());
	    newUser.setLastName(user.getLastName());
	    newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setAge(user.getAge());
		newUser.setSalary(user.getSalary());
        return userDao.save(newUser);
    }
    
    @Override
    public User saveFromUI(UserDto user) {
	    User newUser = new User();
	    newUser.setUsername(user.getUsername());
	    newUser.setFirstName(user.getFirstName());
	    newUser.setLastName(user.getLastName());
	    newUser.setPassword(user.getPassword());
		newUser.setAge(user.getAge());
		newUser.setSalary(user.getSalary());
		Optional<ImageModel> model=imageRepository.findById(user.getIdImage());
		ImageModel imageObj= new ImageModel();
		imageObj.setId(model.get().getId());
		imageObj.setName(model.get().getName());
		imageObj.setPicByte(model.get().getPicByte());
		imageObj.setType(model.get().getType());
		newUser.setIdImage(imageObj);
        return userDao.save(newUser);
    }
}
