package com.devglan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class Application extends SpringBootServletInitializer {

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

 /*   @Bean
    public CommandLineRunner init(UserDao userDao){
        return args -> {
            User user1 = new User();
            user1.setFirstName("Jithendra");
            user1.setLastName("Madugundu");
            user1.setSalary(12345);
            user1.setAge(23);
            user1.setUsername("jithu");
            user1.setPassword(passwordEncoder.encode("jithu123"));
            userDao.save(user1);

            User user2 = new User();
            user2.setFirstName("Vinod");
            user2.setLastName("Kumar");
            user2.setSalary(4567);
            user2.setAge(34);
            user2.setUsername("vinod");
            user2.setPassword(passwordEncoder.encode("vinod@shan"));
            userDao.save(user2);
        };
    }*/

}
