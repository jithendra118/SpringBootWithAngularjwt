package com.devglan.config;

import com.devglan.model.ApiResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionAdvice {

    @ExceptionHandler(RuntimeException.class)
    public ApiResponse<Object> handleNotFoundException(RuntimeException ex) {
        ApiResponse<Object> apiResponse = new ApiResponse<Object>(400, "Bad request", null);
        return apiResponse;
    }

}
