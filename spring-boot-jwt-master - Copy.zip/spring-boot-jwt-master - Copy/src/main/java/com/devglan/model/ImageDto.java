package com.devglan.model;

import org.springframework.web.multipart.MultipartFile;

public class ImageDto {
	private MultipartFile file;
	private UserDto user;
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public UserDto getUser() {
		return user;
	}
	public void setUser(UserDto user) {
		this.user = user;
	}
	

}
