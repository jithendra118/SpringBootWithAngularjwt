package com.devglan.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.devglan.model.User;

public interface TutorialRepository extends JpaRepository<User, Long> {
  Page<User> findByFirstName(String username, Pageable pageable);

  Page<User> findByUsername(String username, Pageable pageable);
  
  List<User> findByUsername(String username, Sort sort);
}
