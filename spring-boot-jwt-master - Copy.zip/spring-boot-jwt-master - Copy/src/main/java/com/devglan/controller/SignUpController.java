package com.devglan.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devglan.dao.ImageRepository;
import com.devglan.model.ApiResponse;
import com.devglan.model.ImageModel;
import com.devglan.model.User;
import com.devglan.model.UserDto;
import com.devglan.service.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/signUp")
public class SignUpController {
	
    @Autowired
    private UserService userService;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
	ImageRepository imageRepository;
    @PostMapping
    public ApiResponse<User> saveUser(@RequestBody UserDto user){
    	user.setPassword(passwordEncoder.encode(user.getUsername()));
        return new ApiResponse<>(HttpStatus.OK.value(), "User saved successfully.",userService.saveFromUI(user));
    }
    

}
